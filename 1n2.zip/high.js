
    let ASCII_SIZE = 256;
    function getMaxOccuringChar(str)
    {
     
        let count = new Array(ASCII_SIZE);
        for (let i = 0; i < ASCII_SIZE; i++)
        {
            count[i] = 0;
        }
         
    
        let len = str.length;
        for (let i = 0; i < len; i++)
        {
            count[str[i].charCodeAt(0)] += 1;
        }
        let max = -1;  
        let result = ' ';  
         
       
        for (let i = 0; i < len; i++)
        {
            if (max < count[str[i].charCodeAt(0)])
            {
                max = count[str[i].charCodeAt(0)];
                result = str[i];
            }
        }
        return result;
    }
   
   
    let str1 = "absaaab";
    console.log( getMaxOccuringChar(str1) , "is the highest frequency ",);

    let str2= "Best Course Ever";
    console.log( getMaxOccuringChar(str2), "is the highest frequency",);
     

    let str3 = "how are you???";
    console.log( getMaxOccuringChar(str3) , "is the highest frequency",);
     
     
   