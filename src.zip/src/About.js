import React from 'react';
import { text} from 'react-native';

const About = () => {
    <Text>Leaf Constructions is one of the leading construction companies on the land of fire, you can afford the houses easily if you are rich enough. On a simple note yuou can only buy our houses if you have more money.</Text>
}

export default About;
