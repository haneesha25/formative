import React from 'react';
import { Text } from 'react-native';

const Contact = () => {
    <Text>Contact number: 99, Contact Address: Leaf Village</Text>
}

export default Contact;